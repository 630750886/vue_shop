<template>
  <h1>我是rep</h1>
</template>

<script>
  export default {
    name: "Reports"
  }
</script>

<style lang="less" scoped>

</style>