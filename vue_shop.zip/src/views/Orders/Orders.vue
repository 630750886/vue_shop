<template>
  <h1>我是ord</h1>
</template>

<script>
  export default {
    name: "Orders"
  }
</script>

<style lang="less" scoped>

</style>