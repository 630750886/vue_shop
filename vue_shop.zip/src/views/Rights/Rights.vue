<template>
 <div>
   <!--    面包屑-->
   <el-breadcrumb separator-class="el-icon-arrow-right">
     <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
     <el-breadcrumb-item>权限管理</el-breadcrumb-item>
     <el-breadcrumb-item>权限列表</el-breadcrumb-item>
   </el-breadcrumb>
   <!--    卡片-->
   <el-card class="box-card">
     <el-table
         :data="permissionList"
         border>
       <el-table-column type="index"></el-table-column>
       <el-table-column prop="authName" label="权限名称"></el-table-column>
       <el-table-column prop="path" label="路径"></el-table-column>
       <el-table-column prop="level" label="等级">
         <template slot-scope="scope">
           <el-tag v-if="scope.row.level==='0'">一级</el-tag>
           <el-tag v-else-if="scope.row.level==='1'" type="success">二级</el-tag>
           <el-tag v-else type="warning">三级</el-tag>
         </template>
       </el-table-column>
     </el-table>
   </el-card>
 </div>
</template>

<script>
  import {request} from "../../network/request";

  export default {
    name: "Rights",
    data(){
      return {
        permissionList:[]
      }
    },
    created() {
      this.getPermission()
    },
    methods:{
      // 获取权限列表
      getPermission(){
        request({
          url:'rights/list'
        }).then(res=>{
          // console.log(res.data.data)
          this.permissionList=res.data.data
        })
      }
    }
  }
</script>

<style lang="less" scoped>

</style>
