<template>
  <div>
    <h1>欢迎使用周先森电商管理系统！</h1>
    <h3>Welcome to Mr. Zhou e-commerce management system！</h3>
  </div>
</template>

<script>
  export default {
    name: "Welcome"
  }
</script>

<style scoped>

</style>
